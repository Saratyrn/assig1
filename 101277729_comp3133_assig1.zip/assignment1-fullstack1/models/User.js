const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, 'Please provide your username'],
    unique: true,
    trim: true,
    lowercase: true,
  },

  firstname: {
    type: String,
    required: [true, 'Please provide your firstname'],
    trim: true
  },

  lastname: {
    type: String,
    required: [true, 'Please provide your lastname'],
    trim: true
  },

  email: {
    type: String,
    required: true,
    trim: true,
    uppercase: true,
    //Custom validation
    validate: function(value) {
      var emailRegex = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      return emailRegex.test(value);
    }
  },
  password: {
    type: String,
    required: [true, "Please enter your password"],
    minlength: 6
  },

  type:{
    type: String,
    required: [true, "Please enter type of admin or customer"],
    validate: function(value){
      if(value.length == 0 || typeof value === typeof undefined){
        return "Please enter type value";
      }
      if(value != "admin" || value != "customer"){
        return "Please enter only admin or customer as type";
      }
    }
  }
  
});

const User = mongoose.model("User", UserSchema);
module.exports = User;


