const Listing = require("./models/Listing");
const User = require("./models/User");
const Booking = require("./models/Booking");
const jsonwebtoken = require('jsonwebtoken')

exports.resolvers = {
  Query: {
    getListing: async (parent, args) => {
      return await Listing.find({});
    },
    getListingAdminLogin: async(parent,args,context) =>{
      if(context.user && context.user.type === "admin"){
        return await Listing.find({});
      }else{
        throw new Error("Only Admin can view the listings");
      }
    },

    getListingByName: async (parent, args) => {
        return await Listing.find({ listing_title: args.listing_title });
      },
    getListingByCity: async (parent, args) => {
        return await Listing.find({ city: args.city });
    },
    getListingByPostalCode: async (parent, args) => {
        return await Listing.find({ postal_code: args.postal_code });
      },
    getUser: async (parent, args) => {
      return await User.find({});
    },
    getBooking: async (parent, args,context) => {
      if(context.user && context.user.type === "customer"){
        return await Booking.find({});
        
      }else{
        throw new Error("Only Customers can view Bookings");
      }
    }
  },

  Mutation: {
    addListing: async (parent, args) => {
      console.log(args);
      const emailExpression = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      const isValidEmail = emailExpression.test(
        String(args.email).toLowerCase()
      );

      if (!isValidEmail) {
        throw new Error("email not in proper format");
      }

      const userType = await User.findOne({ username: args.username }).select(
        "type"
      );
      if(!userType){
        throw new Error("No user found with username - ", args.username);
      }else if (userType && userType.type != "admin") {
        throw new Error("Only admin can add listing");
      }

      let newListing = new Listing({
        listing_id: args.listing_id,
        listing_title: args.listing_title,
        description: args.description,
        street: args.street,
        city: args.city,
        postal_code: args.postal_code,
        price: args.price,
        email: args.email,
        username: args.username
      });
      return await newListing.save();
    },

    addUser: async (parent, args) => {
      console.log(args);
      const emailExpression = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      const isValidEmail = emailExpression.test(
        String(args.email).toLowerCase()
      );

      if (!isValidEmail) {
        throw new Error("email not in proper format").message;
      }

      if (args.type === "admin" || args.type === "customer") {
      } else {
        throw new Error(
          JSON.stringify("Please enter only admin or customer as type")
        );
      }

      let newUser = new User({
        username: args.username,
        firstname: args.firstname,
        lastname: args.lastname,
        email: args.email,
        password: args.password,
        type: args.type
      });
      return await newUser.save();
    },

    addBooking: async (parent, args) => {
      let newBooking = new Booking({
        listing_id: args.listing_id,
        booking_id: args.booking_id,
        booking_date: args.booking_date,
        booking_start: args.booking_start,
        booking_end: args.booking_end,
        username: args.username
      });
      return await newBooking.save();
    },
    login: async(parent,args) =>{
      const user = await User.findOne({
        username: args.username
      });

      if(!user)
        throw new Error("Username doesn't exist");

      if(user.password !== args.password){
        throw new Error("Please check Password");
      }
      return jsonwebtoken.sign(
        {
          username: user.username,
          type: user.type,
          email: user.email
        },
        "randomgeneratedkey",
        { expiresIn: '30d' }
      )
    },
  }
};
